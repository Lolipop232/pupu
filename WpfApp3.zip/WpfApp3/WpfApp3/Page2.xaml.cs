﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp3
{
    /// <summary>
    /// Логика взаимодействия для Page2.xaml
    /// </summary>
    public partial class Page2 : Page
    {
        string loginperson;
        dbbdEntities context;
        public Page2(string loginperson1)
        {
            InitializeComponent();
            loginperson = loginperson1;
            context = new dbbdEntities();
            dg.ItemsSource = context.zakaz.ToList();
           
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {

        }

        private void tbox_TextChanged(object sender, TextChangedEventArgs e)
        {
            Filter();
        }
        public void Filter()
        {
            List<users> users = context.users.ToList();
            if (cmb.SelectedItem == null && tbox.Text == "")
                return;
            if (cmb.SelectedItem == null)
            {
                dbbdEntities zakaz = cmb.SelectedItem as zakaz;
                zakaz = zakaz.Where(p => p.Status == zakaz.Status).ToList();
            }
            zakaz = zakaz.Where(p => p.Dates.ToList().Contains(TextSearch.ToList()));
            dg.ItemsSource = zakaz;
        }
    }
}
